@echo off
rem Show current state (no changes, no administrator needed).
powershell -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0venue-mode.ps1" -Status
