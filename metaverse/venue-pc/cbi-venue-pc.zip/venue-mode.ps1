﻿# 会場モード（PC側）：テザリング中に裏で通信するものを止める／元に戻す（2026-09-15 中司さん「全てボタン一つで処置できるよう（復旧も）」）
#   会場モードON.bat  → このファイルを -On で管理者実行
#   会場モードOFF.bat → -Off で管理者実行（ON のときに記録した状態へ正確に戻す）
#   お試し（変更しない）: powershell -ExecutionPolicy Bypass -File venue-mode.ps1 -On -DryRun
#   いまの状態:           powershell -ExecutionPolicy Bypass -File venue-mode.ps1 -Status
# ON で行うこと（変更前の値は %LOCALAPPDATA%\cbi-venue-mode.json に記録）：
#   1. いま接続している Wi-Fi を「従量制課金接続」に（Windows が自動ダウンロードを控える）
#   2. Windows Update・配信の最適化・BITS・Edge/Chrome の自動更新サービスを停止し、起動しないように
#   3. Windows Update を 7 日間一時停止（設定アプリの「一時停止」と同じレジストリ）
#   4. OneDrive を終了（同期を止める）
#   5. Microsoft Store のアプリ自動更新を止める
#   6. 24時間後に自動で OFF が走る予約（タスクスケジューラ CBI-VenueModeOff）を登録（OFF を忘れても翌日には戻る。2026-09-16）
# OFF は記録ファイルが無くても（消えた・別のPCで ON した等）Windows の標準的な設定へ戻す（2026-09-16 中司さん「他人が開くと不具合出ますか」）
# 3Dワールド側（街並みの記憶量・通信節約・事前読み込み）はブラウザの ⚙設定「🏟 会場モード」で行う（このスクリプトの範囲外）
param(
  [switch]$On,
  [switch]$Off,
  [switch]$Status,
  [switch]$DryRun,
  [switch]$Auto
)
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$StateFile = Join-Path $env:LOCALAPPDATA "cbi-venue-mode.json"
$Services = @("wuauserv", "DoSvc", "BITS", "edgeupdate", "edgeupdatem")
$UxKey = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"
$PauseNames = @("PauseUpdatesExpiryTime", "PauseFeatureUpdatesStartTime", "PauseFeatureUpdatesEndTime", "PauseQualityUpdatesStartTime", "PauseQualityUpdatesEndTime")
$StoreKey = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore"
$TaskName = "CBI-VenueModeOff"
$LogFile = Join-Path $env:LOCALAPPDATA "cbi-venue-mode.log"
# 記録が無いときに戻す先（Windows 11 の標準的な起動設定。Manual＝必要なときだけ起動する）
$DefaultStart = @{ wuauserv = "Manual"; DoSvc = "Automatic"; BITS = "Manual"; edgeupdate = "Automatic"; edgeupdatem = "Manual" }

function Say($msg) { Write-Host $msg; if ($Auto) { try { Add-Content -Path $LogFile -Value ((Get-Date).ToString("s") + " " + $msg) -Encoding UTF8 } catch {} } }
function Act($msg) { if ($DryRun) { Write-Host ("  [お試し・変更なし] " + $msg) -ForegroundColor Yellow } else { Write-Host ("  " + $msg) -ForegroundColor Cyan } }
function IsAdmin() {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function ConnectedSsid() {
  $out = netsh wlan show interfaces 2>$null
  foreach ($line in $out) {
    if ($line -match "^\s*SSID\s*:\s*(.+)$") { return $Matches[1].Trim() }
  }
  return $null
}
function ProfileCost($ssid) {
  $out = netsh wlan show profile name="$ssid" 2>$null
  foreach ($line in $out) { if ($line -match "(コスト|Cost)\s*:\s*(.+)$") { return $Matches[2].Trim() } }
  return $null
}
function UpdaterServices() {
  # Google Chrome の更新サービスは名前に版が付く（例 GoogleUpdaterService152.0.7933.0）
  $list = @()
  foreach ($n in $Services) { $s = Get-Service -Name $n -ErrorAction SilentlyContinue; if ($s) { $list += $s } }
  $list += Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "GoogleUpdater*" -or $_.Name -like "gupdate*" }
  return $list
}
function ScheduleOff() {
  # 24時間後に -Off -Auto を管理者権限で実行する予約。ログオンしていなければ次にログオンしたときに走る（StartWhenAvailable）
  $when = (Get-Date).AddHours(24)
  Act ("24時間後（" + $when.ToString("M/d HH:mm") + "）に自動で OFF が走る予約を登録する（帰るのが早ければ 会場モードOFF.bat で先に戻せる）")
  if ($DryRun) { return }
  try {
    $act = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ("-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"" + $PSCommandPath + "`" -Off -Auto")
    $trg = New-ScheduledTaskTrigger -Once -At $when
    $pri = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $TaskName -Action $act -Trigger $trg -Principal $pri -Settings $set -Force | Out-Null
  } catch { Say "    予約できず（OFF は手で実行してください）: $($_.Exception.Message)" }
}
function UnscheduleOff() {
  if (-not (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue)) { return }
  Act "自動 OFF の予約を消す"
  if (-not $DryRun) { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue }
}
function ReadState() { if (Test-Path $StateFile) { return Get-Content $StateFile -Raw -Encoding UTF8 | ConvertFrom-Json } else { return $null } }

function Do-On() {
  if (Test-Path $StateFile) { Say "すでに会場モードです（記録 $StateFile があります）。先に 会場モードOFF.bat を実行してください。"; return 2 }
  $state = [ordered]@{ at = (Get-Date).ToString("s"); wifi = $null; wifiCost = $null; services = @(); pause = @{}; onedrive = $null; storeAutoDownload = "absent" }
  Say "=== 会場モード ON（テザリングの裏通信を止めます）==="
  # 1. Wi-Fi 従量制
  $ssid = ConnectedSsid
  if ($ssid) {
    $state.wifi = $ssid; $state.wifiCost = ProfileCost $ssid
    Act "Wi-Fi「$ssid」を従量制課金接続にする（いま: $($state.wifiCost)）"
    if (-not $DryRun) { netsh wlan set profileparameter name="$ssid" cost=Fixed | Out-Null }
  } else { Say "  Wi-Fi は未接続（有線・USBテザリングのときはここは何もしない）" }
  # 2. サービス停止
  foreach ($s in (UpdaterServices)) {
    $state.services += [ordered]@{ name = $s.Name; startType = [string]$s.StartType; wasRunning = ($s.Status -eq "Running") }
    Act "サービス $($s.Name) を停止して無効に（いま: $($s.Status) / $($s.StartType)）"
    if (-not $DryRun) {
      try { Stop-Service -Name $s.Name -Force -ErrorAction Stop } catch { Say "    停止できず: $($_.Exception.Message)" }
      try { Set-Service -Name $s.Name -StartupType Disabled -ErrorAction Stop } catch { Say "    無効にできず: $($_.Exception.Message)" }
    }
  }
  # 3. Windows Update 7日間停止
  $start = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"); $end = (Get-Date).ToUniversalTime().AddDays(7).ToString("yyyy-MM-ddTHH:mm:ssZ")
  $cur = Get-ItemProperty $UxKey -ErrorAction SilentlyContinue
  foreach ($n in $PauseNames) { $v = if ($cur -and $cur.PSObject.Properties[$n]) { [string]$cur.$n } else { $null }; $state.pause[$n] = $v }
  Act "Windows Update を 7 日間一時停止（$end まで）"
  if (-not $DryRun) {
    if (-not (Test-Path $UxKey)) { New-Item -Path $UxKey -Force | Out-Null }
    foreach ($n in $PauseNames) { $val = if ($n -like "*StartTime") { $start } else { $end }; Set-ItemProperty -Path $UxKey -Name $n -Value $val -Type String }
  }
  # 4. OneDrive 終了
  $od = Get-Process -Name OneDrive -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($od) {
    $state.onedrive = $od.Path
    Act "OneDrive を終了する（$($od.Path)）"
    if (-not $DryRun) { Stop-Process -Name OneDrive -Force -ErrorAction SilentlyContinue }
  } else { Say "  OneDrive は動いていない" }
  # 5. Store 自動更新
  $sv = Get-ItemProperty $StoreKey -Name AutoDownload -ErrorAction SilentlyContinue
  if ($sv) { $state.storeAutoDownload = [string]$sv.AutoDownload }
  Act "Microsoft Store のアプリ自動更新を止める（いま: $($state.storeAutoDownload)）"
  if (-not $DryRun) {
    if (-not (Test-Path $StoreKey)) { New-Item -Path $StoreKey -Force | Out-Null }
    Set-ItemProperty -Path $StoreKey -Name AutoDownload -Value 2 -Type DWord
  }
  if (-not $DryRun) { $state | ConvertTo-Json -Depth 5 | Set-Content -Path $StateFile -Encoding UTF8; Say "記録: $StateFile" }
  # 6. 24時間後の自動 OFF
  ScheduleOff
  Say "=== 完了。帰ったら 会場モードOFF.bat で元に戻してください（忘れても24時間後に自動で戻ります）==="
  Say "※ ブラウザ側は 3Dワールド（?mode=musashiya）の ⚙設定「🏟 会場モード」を ON にすること"
  return 0
}

function Do-Off() {
  $state = ReadState
  if (-not $state) { return (Do-OffDefault) }
  Say "=== 会場モード OFF（$($state.at) の記録どおりに戻します）==="
  UnscheduleOff
  if ($state.wifi) {
    $cost = if ($state.wifiCost -and $state.wifiCost -match "(固定|Fixed)") { "Fixed" } elseif ($state.wifiCost -and $state.wifiCost -match "(変動|Variable)") { "Variable" } else { "Unrestricted" }
    Act "Wi-Fi「$($state.wifi)」のコストを $cost に戻す"
    if (-not $DryRun) { netsh wlan set profileparameter name="$($state.wifi)" cost=$cost | Out-Null }
  }
  foreach ($s in $state.services) {
    Act ("サービス $($s.name) を $($s.startType) に戻す" + $(if ($s.wasRunning) { "（起動する）" } else { "" }))
    if (-not $DryRun) {
      try { Set-Service -Name $s.name -StartupType $s.startType -ErrorAction Stop } catch { Say "    戻せず: $($_.Exception.Message)" }
      if ($s.wasRunning) { try { Start-Service -Name $s.name -ErrorAction Stop } catch { Say "    起動できず: $($_.Exception.Message)" } }
    }
  }
  Act "Windows Update の一時停止を解除（元の値へ）"
  if (-not $DryRun) {
    foreach ($n in $PauseNames) {
      $v = $state.pause.$n
      if ($null -eq $v -or $v -eq "") { Remove-ItemProperty -Path $UxKey -Name $n -ErrorAction SilentlyContinue } else { Set-ItemProperty -Path $UxKey -Name $n -Value $v -Type String }
    }
  }
  if ($state.onedrive) {
    Act "OneDrive を起動する（$($state.onedrive)）"
    if (-not $DryRun) { Start-Process -FilePath $state.onedrive -ArgumentList "/background" -ErrorAction SilentlyContinue }
  }
  Act "Microsoft Store の自動更新の設定を戻す（元: $($state.storeAutoDownload)）"
  if (-not $DryRun) {
    if ($state.storeAutoDownload -eq "absent") { Remove-ItemProperty -Path $StoreKey -Name AutoDownload -ErrorAction SilentlyContinue } else { Set-ItemProperty -Path $StoreKey -Name AutoDownload -Value ([int]$state.storeAutoDownload) -Type DWord }
  }
  if (-not $DryRun) { Remove-Item $StateFile -Force; Say "記録を消しました: $StateFile" }
  Say "=== 完了（元に戻しました）==="
  return 0
}

# 記録ファイルが無いとき（消えた・OFF を2回押した等）：何が変わっていても Windows の標準的な設定へ戻す
function Do-OffDefault() {
  Say "=== 会場モード OFF（記録 $StateFile が無いので、標準の設定へ戻します）==="
  UnscheduleOff
  $ssid = ConnectedSsid
  if ($ssid) {
    Act "Wi-Fi「$ssid」の従量制を解除する（Unrestricted）"
    if (-not $DryRun) { netsh wlan set profileparameter name="$ssid" cost=Unrestricted | Out-Null }
  }
  foreach ($s in (UpdaterServices)) {
    $st = if ($DefaultStart.ContainsKey($s.Name)) { $DefaultStart[$s.Name] } else { "Automatic" }
    if ([string]$s.StartType -eq "Disabled") {
      Act "サービス $($s.Name) を $st に戻す"
      if (-not $DryRun) { try { Set-Service -Name $s.Name -StartupType $st -ErrorAction Stop } catch { Say "    戻せず: $($_.Exception.Message)" } }
    } else { Say "  サービス $($s.Name) は $($s.StartType) のまま（変えない）" }
  }
  Act "Windows Update の一時停止を解除する"
  if (-not $DryRun) { foreach ($n in $PauseNames) { Remove-ItemProperty -Path $UxKey -Name $n -ErrorAction SilentlyContinue } }
  if (-not (Get-Process -Name OneDrive -ErrorAction SilentlyContinue)) {
    $exe = @("$env:LOCALAPPDATA\Microsoft\OneDrive\OneDrive.exe", "$env:ProgramFiles\Microsoft OneDrive\OneDrive.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if ($exe) { Act "OneDrive を起動する（$exe）"; if (-not $DryRun) { Start-Process -FilePath $exe -ArgumentList "/background" -ErrorAction SilentlyContinue } }
  }
  Act "Microsoft Store の自動更新の設定を戻す（ポリシーを消す）"
  if (-not $DryRun) { Remove-ItemProperty -Path $StoreKey -Name AutoDownload -ErrorAction SilentlyContinue }
  Say "=== 完了（標準の設定へ戻しました）==="
  return 0
}

function Do-Status() {
  $state = ReadState
  Say ("会場モード: " + $(if ($state) { "ON（$($state.at) から）" } else { "OFF" }))
  $ssid = ConnectedSsid
  Say ("Wi-Fi: " + $(if ($ssid) { "$ssid（コスト: " + (ProfileCost $ssid) + "）" } else { "未接続" }))
  foreach ($s in (UpdaterServices)) { Say ("サービス " + $s.Name.PadRight(42) + [string]$s.Status + " / " + [string]$s.StartType) }
  $cur = Get-ItemProperty $UxKey -ErrorAction SilentlyContinue
  Say ("Windows Update 一時停止の期限: " + $(if ($cur -and $cur.PauseUpdatesExpiryTime) { $cur.PauseUpdatesExpiryTime } else { "なし" }))
  Say ("OneDrive: " + $(if (Get-Process -Name OneDrive -ErrorAction SilentlyContinue) { "動作中" } else { "停止" }))
  $tk = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  Say ("自動 OFF の予約: " + $(if ($tk) { "あり（" + ((Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue).NextRunTime) + "）" } else { "なし" }))
  return 0
}

if ($Status) { exit (Do-Status) }
if (-not ($On -or $Off)) { Say "使い方: -On ／ -Off ／ -Status ／ -On -DryRun"; exit 1 }
if (-not $DryRun -and -not (IsAdmin)) { Say "管理者として実行してください（会場モードON.bat／OFF.bat を使うと管理者で開きます）"; exit 3 }
if ($On) { exit (Do-On) } else { exit (Do-Off) }
